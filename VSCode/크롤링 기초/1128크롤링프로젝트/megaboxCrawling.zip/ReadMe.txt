1. MegaBoxCrawling.ipynb 파일의 내용을 순서대로 실행

2. 1번의 파일 실행하면 생성되는 파일인 megaBoxCrawing.csv, Megabox_Zootoppia2_Seoul_1129.csv 확인

3. go.ipynb의 내용 순차 실행하여 데이터 프레임 생성하여 결과 확인